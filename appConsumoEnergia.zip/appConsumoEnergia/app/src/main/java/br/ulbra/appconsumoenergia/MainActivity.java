package br.ulbra.appconsumoenergia;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText edtPotencia, edtTempoDeUso, edtCusto;
    Button btnCalcular;
    TextView txtResposta1, txtResposta2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtPotencia = findViewById(R.id.edtPotencia);
        edtTempoDeUso = findViewById(R.id.edtTempoDeUso);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResposta1 = findViewById(R.id.txtResposta1);
        txtResposta2 = findViewById(R.id.txtResposta2);
        edtCusto = findViewById(R.id.edtCusto);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double p, t, c,result1,  result2;

                try {
                    p = Double.parseDouble(edtPotencia.getText().toString());
                    t = Double.parseDouble(edtTempoDeUso.getText().toString());
                    c = Double.parseDouble(edtCusto.getText().toString());

                    result1 = (p * t) / 1000;
                    result2 = result1 * c;

                    txtResposta1.setText("O cosumo de energia é: " + result1 + "KW/H");
                    txtResposta2.setText("O custo de energia em KW/H é: R$ " + result2);
                }catch (NumberFormatException E){
                    Toast.makeText(MainActivity.this, "Tente novamente mais tarde!", Toast.LENGTH_SHORT).show();
                }

            }
        });



        };
    }
